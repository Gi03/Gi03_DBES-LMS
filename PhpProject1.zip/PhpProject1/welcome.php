<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: Login.php");
    exit;
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome</title>
    <style>
        body{ font: 14px sans-serif; text-align: center; }
    </style>
</head>
<body>
     
    <h1 class="my-5">Hi, <b><?php echo htmlspecialchars($_SESSION["username"]); ?></b>. Welcome to our site.</h1>
    <p>
        <a href="Reset-Password.php" class="btn btn-warning">Reset Your Password</a>
        <a href="Logout.php" class="btn btn-danger ml-3">Sign Out of Your Account</a>
    </p>
 <form method="post" action="">
 	Category name: <input type="text" name="cat_name" />
 	Category description: <textarea name="cat_description" /></textarea>
	<input type="submit" value="Add category" />
 </form>
    <table>
        <th>Content</th>
        
    </table>
</body>
</html>